#ifndef TOOLS_H_
#define TOOLS_H_
#include "Point.h"

Point getUpView(Point eye, Point towards);

#endif
