#include "Automaton.h"

int main(int argc, char **argv){
	glutInit(&argc, argv);
	generator(N, M);
	Me.initPosition();
	openGLInit();
	return 0;
}
